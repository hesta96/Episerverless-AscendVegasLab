//>>built
define("dojo/loadInit",["./_base/loader"],function(_1){return {dynamic:0,normalize:function(id){return id;},load:_1.loadInit};});